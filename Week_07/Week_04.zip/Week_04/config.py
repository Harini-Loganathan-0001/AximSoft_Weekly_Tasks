import os

class Config:
    SECRET_KEY = "secretkey123"
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "instance", "courses.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
